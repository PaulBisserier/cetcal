<?php
// Prepare navigation :
$nav = htmlspecialchars($_POST['qstprod-signupgen-nav']);
if ($nav != 'valider' && $nav != 'retour') { /*Error de navigation TODO.*/ $nav = 'retour'; }
$status = $nav == 'valider' ? 'signupprods.form' : '';
$whitelist = ['127.0.0.1', '::1', 'localhost'];
$localhost = in_array($_SERVER['REMOTE_ADDR'], $whitelist);

/* *****************************************************************************/
/* HTTP POST : var setup : *****************************************************/
// POST form logic - dans l'ordre du formulaire HTML :
$dataProcessor = new HTTPDataProcessor();
$form_obl_nom = $dataProcessor->processHttpFormData($_POST['qstprod-nom']);
$form_obl_prenom = $dataProcessor->processHttpFormData($_POST['qstprod-nom']);
$form_obl_email = $dataProcessor->processHttpFormData($_POST['qstprod-email']);
$form_obl_emailconf = $dataProcessor->processHttpFormData($_POST['qstprod-email-conf']);
$form_obl_mdp = $dataProcessor->processHttpFormData($_POST['qstprod-mdp']);
$form_obl_mdpconf = $dataProcessor->processHttpFormData($_POST['qstprod-mdpconf']);
$form_telfix = $dataProcessor->processHttpFormData($_POST['qstprod-numbtel-fix']);
$form_telport = $dataProcessor->processHttpFormData($_POST['qstprod-numbtel-port']);

$form_obl_nomferme = $dataProcessor->processHttpFormData($_POST['qstprod-nomferme']);
$form_obl_siret = $dataProcessor->processHttpFormData($_POST['qstprod-siret']);
$form_adr_numvoie = $dataProcessor->processHttpFormData($_POST['qstprod-numvoie']);
$form_adr_rue = $dataProcessor->processHttpFormData($_POST['qstprod-rue']);
$form_adr_lieudit = $dataProcessor->processHttpFormData($_POST['qstprod-lieudit']);
$form_adr_commune = $dataProcessor->processHttpFormData($_POST['qstprod-commune']);
$form_adr_cp =$dataProcessor->processHttpFormData($_POST['qstprod-cp']);
$form_adr_cmpladr = $dataProcessor->processHttpFormData($_POST['qstprod-cmpladrs']);

$form_pagefb = $dataProcessor->processHttpFormData($_POST['qstprod-fb']);
$form_pageig = $dataProcessor->processHttpFormData($_POST['qstprod-ig']);
$form_pagetwitter = $dataProcessor->processHttpFormData($_POST['qstprod-twitter']);
$form_siteweb = $dataProcessor->processHttpFormData($_POST['qstprod-www']);
$form_boutiquewww = $dataProcessor->processHttpFormData($_POST['qstprod-adrwebboutiqueenligne']);

$form_anneeinstall = $dataProcessor->processHttpFormData($_POST['qstprod-anneeinstall']);
$form_syndc = $dataProcessor->processHttpFormData($_POST['qstprod-syndc']);
$form_orgcertifbio = $dataProcessor->processHttpFormData($_POST['qstprod-orgcertifbio']);
$form_typeprod = $dataProcessor->processHttpFormData($_POST['qstprod-typeprod']);
$form_surfacepc = $dataProcessor->processHttpFormData($_POST['qstprod-surfacepc']);
$form_surfaceserre = $dataProcessor->processHttpFormData($_POST['qstprod-supserre']);

$form_qstgen_lieuxdist = $dataProcessor->processHttpFormData($_POST['qstprod-ldist-qstgen[]']);
$form_qstgen_libre = $dataProcessor->processHttpFormData($_POST['qstprod-qstbesoinlibre']);

$dataProcessor->scanForErrors();
/* *****************************************************************************/

// Apply navigation :
$localhost ? header('Location: /?status='.$status) : header('Location: /?status='.$status);
exit();
?>

<?php
Class HTTPDataProcessor 
{

  /**
   * Contains all error messages.
   */
  private $errors = new Array();

  /**
   * Control/check input. When data is unset, appends to error message array for View layer purposes.
   * param0  : the data to check.
   * param1  : the label to add to a generic Error (thrown to code using this).
   * returns : the param0 data processed and safe for database.
   */
  public function processHttpFormData($data, $dataLabel)
  {
    if (!isset($data)) array_push($this->errors, "Le champ ".$dataLabel." est obligatoire et n'est pas renseigné.");
    else return htmlspecialchars($data);
  }

  public function scanForErrors() throws OblHttpFormDataException
  {
    if (count($this->errors) > 0) 
    {
      // Prepare to sendback to View layers.
    }
  }

}
<?