<script src="/src/scripts/js/cetcal/cetcal.min.lieuxdist.js"></script>
<!-- singup lieux de distribution informations html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez renseigner une fiche pour chaque lieux de distribution</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos informations de lieux de distribution.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form class="form" method="post" action="/src/app/controller/cet.qstprod.controller.signuplieuxdist.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner vos lieux de distribution ou collaborateurs :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <br>
      <label for="qstprod-nomlieuxdist"><small class="form-text text-muted">Renseignez un lieux de distribution ou organisme, puis ajouter à la liste :</small></label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <span class="input-group-text" id="qstprod-labelnomlieuxdist">Lieux de dist. ou organisme :</span>
          </div>
          <select class="form-control custom-select" id="qstprod-nomlieuxdist" 
            name="qstprod-nomlieuxdist" aria-describedby="qstprod-labelnomlieuxdist">
            <option></option>
            <option>Castillonnais En Transition</option>
            <option>BIO Asso n°1</option>
            <option>Association pour la consomation en circuits courts n°2</option>
            <option>BIO Asso n°2</option>
            <option>BIO Asso n°3</option>
            <option>BIO Asso n°4</option>
            <option>BIO Asso n°5</option>
            <option>BIO Asso n°6</option>
            <option>BIO Asso n°7</option>
          </select>
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-nomlieuxdistinconnu" name="qstprod-nomlieuxdistinconnu" type="text" placeholder="Nom du lieux de distribution si inexistant dans la liste.">
        </div>
        <div class="input-group mb-3">  
          <input class="form-control" id="qstprod-datelieuxdist" name="qstprod-datelieuxdist" type="text" 
            placeholder="Date approximative de la prochaine livraison (format jj/mm/aaaa)"
            onblur="checkFRDateFormat(false, this.id);">
        </div>
        <div class="input-group mb-3">  
          <input class="form-control is-invalid" id="qstprod-periodicitedist" name="qstprod-periodicitedist" 
            type="number" placeholder="Périodicité de distribution mensuelle"
            onblur="checkFormInputInteger(30, 1, this.id);">
        </div>
        <div class="row">
          <div class="col"> 
            <button type="button" class="btn btn-sm btn-primary" style="float: right;" 
              onclick="appendToTBody_lieuxdist('qstprod-table-lieuxdist', 'qstprod-nomlieuxdist', 'qstprod-datelieuxdist', 'qstprod-periodicitedist');">
              Ajouter ce lieux de distribution
            </button>
          </div>
        </div>
      </div>

      <!-- ------------------------- -->
      <!-- ZONE de récap produits.   -->
      <!-- ------------------------- -->
      <div id="qstprod-table-lieuxdist" class="alert alert-success table-responsive" role="alert" style="display: none; margin-top: 20px;">
        <label> - Récapitulatif de vos lieux de distribution :</label>
        <div class="d-flex justify-content-center">
          <table class="table table-borderless table-striped table-hover">
            <thead class="thead-light">
              <tr>
                <th scope="col">lieux de distribution</th>
                <th scope="col">Journée/date</th>
                <th scope="col">Périodicité/mois</th>
              </tr>
            </thead>
            <tbody style="cursor: pointer;"></tbody>
          </table>
        </div>
      </div>

      <div class="row" style="margin-top: 12px;">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onfocus="$('#qstprod-signuplieuxdist-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onfocus="$('#qstprod-signuplieuxdist-nav').val('valider');">Valider ces informations</button>
        </div>
      </div>

      <input type="text" name="qstprod-signuplieuxdist-nav" id="qstprod-signuplieuxdist-nav" value="unset" hidden="hidden">
    </form>
  </div>
</div>