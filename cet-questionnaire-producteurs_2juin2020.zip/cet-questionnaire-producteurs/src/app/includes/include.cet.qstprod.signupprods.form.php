<?php
// DTOs used here :
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupprods.dto.php');
// Prepare Session usage :
$cetcal_session_id = htmlentities(htmlspecialchars($_GET['sitkn']));
session_id($cetcal_session_id);
session_start();
$produits = isset($_SESSION['signupprods.form']) ? unserialize($_SESSION['signupprods.form']) : NULL; 
$recapProduitsDisplay = ($produits === NULL || count($produits) === 0) ? 'none' : 'block';
?>
<!-- singup produits html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez renseigner une fiche pour chaque produit.</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos fiches produits à tous moment.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form id="signupprods.form" class="form" method="post" 
      action="/src/app/controller/cet.qstprod.controller.signupprods.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner vos informations produits :
        <small class="form-text cet-qstprod-label-text" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <div id="cet-types-produits">
        <label><small class="form-text cet-qstprod-label-text">Spécificités de vos produits, Label, type d'agriculture :</small></label>
        <div class="cet-formgroup-container">
          <?php $counter = 0; ?>
          <?php foreach ($listes_arrays->type_culture as $culture) : ?>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?= $culture; ?>" id="qstprod-produit-typeculture-<?= $counter; ?>" name="qstprod-produit-typeculture[]">
            <label class="form-check-label cet-qstprod-label-text" for="qstprod-produit-typeculture-<?= $counter; ?>"><?= $culture; ?></label>
          </div>
          <?php ++$counter; ?>
          <?php endforeach; ?>
        </div>

        <label class="cet-formgroup-container-label"><small class="form-text cet-qstprod-label-text">Dites-nous quels sont vos catégories de produits :</small></label>
        <div class="cet-formgroup-container">
          <span class="badge badge-pill badge-success" style="margin-bottom: 6px;">Les produits frais et les périssables : </span>
          <?php $counter = 0; ?>
          <?php foreach ($listes_arrays->produits_frais as $produitFrais) : ?>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?= $produitFrais; ?>" id="qstprod-produit-frais-<?= $counter; ?>" name="qstprod-produit-frais[]">
            <label class="form-check-label cet-qstprod-label-text" for="qstprod-produit-frais-<?= $counter; ?>"><?= $produitFrais; ?></label>
          </div>
          <?php ++$counter; ?>
          <?php endforeach; ?>
          <label class="cet-formgroup-container-label"><small class="form-text cet-qstprod-label-text">Si vous ne trouvez pas votre produit dans la liste, vous pouvez effectuer une recherche :</small></label>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="qstprod-produits-fruitslegumes-recherche-label">Recherche d'un produit :</span>
            </div>
            <input class="form-control" id="qstprod-produits-fruitslegumes-recherche" 
              name="qstprod-produits-fruitslegumes-recherche" type="text" placeholder="Entrer une recherche puis sélectionner dans la liste"
              aria-describedby="qstprod-produits-fruitslegumes-recherche-label" list=fruitslegumesrecherche>
            <datalist style="" id=fruitslegumesrecherche>
              <?php foreach ($listes_arrays->recherche_fruits_legumes as $fruitLegumeRecherche) : ?>
              <option value="<?= $fruitLegumeRecherche; ?>"></option>
              <?php endforeach; ?>
            </datalist>
          </div>
          <br>
          <span class="badge badge-pill badge-warning" style="margin-bottom: 6px;">Les produits d'épicerie, fruits secs, conserves, non-périssables... :</span>
          <?php $counter = 0; ?>
          <?php foreach ($listes_arrays->produits_secs as $produitSecs) : ?>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?= $produitSecs; ?>" id="qstprod-produit-secs-<?= $counter; ?>" name="qstprod-produit-secs[]">
            <label class="form-check-label cet-qstprod-label-text" for="qstprod-produit-secs-<?= $counter; ?>"><?= $produitSecs; ?></label>
          </div>
          <?php ++$counter; ?>
          <?php endforeach; ?>
          <br>
          <span class="badge badge-pill badge-info" style="margin-bottom: 6px;">Les boissons, vins, bières, avec ou sans alcool :</span>
          <?php $counter = 0; ?>
          <?php foreach ($listes_arrays->produits_boissons as $boisson) : ?>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?= $boisson; ?>" id="qstprod-produit-boisson-<?= $counter; ?>" name="qstprod-produit-boisson[]">
            <label class="form-check-label cet-qstprod-label-text" for="qstprod-produit-boisson-<?= $counter; ?>"><?= $boisson; ?></label>
          </div>
          <?php ++$counter; ?>
          <?php endforeach; ?>
          <br>
          <span class="badge badge-pill badge-primary" style="margin-bottom: 6px;">Catégorie de produits "autres" :</span>
          <?php $counter = 0; ?>
          <?php foreach ($listes_arrays->produits_autres as $autre) : ?>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?= $autre; ?>" id="qstprod-produit-autre-<?= $counter; ?>" name="qstprod-produit-autre[]">
            <label class="form-check-label cet-qstprod-label-text" for="qstprod-produit-autre-<?= $counter; ?>"><?= $autre; ?></label>
          </div>
          <?php ++$counter; ?>
          <?php endforeach; ?>
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="cet-qstprod-label-text">Autre chose ? Renseigner votre type de produit <i>autre</i> :</small></label>
            <input class="form-control" id="qstprod-produit-autre-autre" name="qstprod-produit-autre-autre" type="text" placeholder="Renseigner un type de produit autre" maxlength="30">
          </div>
  
          <div class="row">
            <div class="col"> 
              <label><small><i>Vous avez la possibilité de détailler chaque produit, et ainsi donner d'avantage de précisions aux consomateurs. Pour cela, saisir une ou des fiche(s) produit(s) détaillée(s) :</i></small></label>
              <button type="button" class="btn btn-sm btn-block btn-success" style="float: right;"
                onclick="displayFicheProduit();">Saisir une fiche produit détaillée</button>
            </div>  
          </div>  

        </div>
      </div>

      <div id="cet-fiche-produit" style="display: none;">
        <label for="qstprod-nomprd"><small class="form-text cet-qstprod-label-text">Renseignez la fiche produit, puis ajouter à la liste :</small></label>
        <div class="cet-formgroup-container">
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="cet-qstprod-label-text">Nom du produit :</small></label>
            <input class="form-control is-invalid" id="qstprod-nomprd" name="qstprod-nomprd" 
              type="text" placeholder="Nom du produit, exemple : tomate"
              onblur="checkFormInputMin(30, 2, this.id);">
          </div>
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="cet-qstprod-label-text">Type de produit :</small></label>
            <input class="form-control" id="qstprod-typeprd" name="qstprod-typeprd" type="text" 
              placeholder="Type de produit, exemple : marmande">
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6">
              <label><small class="form-text cet-qstprod-label-text">Indiquer les dates de début et fin pour la saisonnalité de ce produit :</small></label>
            </div>
            <div class="form-group col-lg-3">
              <input type="text" class="form-control" id="qstprod-datedebut-saisonnaliteprd" 
                name="qstprod-datedebut-saisonnaliteprd" 
                onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date début">
            </div>
            <div class="form-group col-lg-3">
              <input type="text" class="form-control" id="qstprod-datefin-saisonnaliteprd" 
                name="qstprod-datefin-saisonnaliteprd" 
                onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date fin">
            </div>
          </div>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="qstprod-labelpopprd">Auprès des consomateurs, ce produit est pour vous :</span>
            </div>
            <select class="form-control custom-select is-invalid" id="qstprod-popprd" 
              name="qstprod-popprd" aria-describedby="qstprod-labelpopprd" onblur="checkFormInputMin(30, 2, this.id);">
              <option></option>
              <option>populaire !</option>
              <option>difficile...</option>
              <option>à développer</option>
              <option>mon meilleur produit !</option>
              <option>un produit rare</option>
            </select>
          </div>  
          <div class="row">
            <div class="col"> 
              <button type="submit" class="btn btn-sm btn-success" style="float: right; margin-left: 3px;"
                onmousedown="$('#qstprod-signupprods-nav').val('ajouter');">Ajouter ce produit</button>
              <button type="button" class="btn btn-sm btn-primary" style="float: right;"
                onclick="displayFicheProduit();">Annuler</button>
            </div>  
          </div>
        </div>
      </div>
      
      <!-- ------------------------- -->
      <!-- ZONE de récap produits.   -->
      <!-- ------------------------- -->
      <div id="qstprod-table-produits" class="alert alert-success table-responsive" role="alert" 
        style="display: <?= $recapProduitsDisplay; ?>; margin-top: 20px;">
        <label> - Récapitulatif de vos fiches produits détaillées :</label>
        <div class="d-flex justify-content-center">
          <table class="table table-borderless table-striped table-hover">
            <thead class="thead-light">
              <tr>
                <th scope="col">Actions</th>
                <th scope="col">Nom</th>
                <th scope="col">Type</th>
                <th scope="col">Du,</th>
                <th scope="col">Au</th>
                <th scope="col">C'est un produit</th>
              </tr>
            </thead>
            <tbody style="cursor: pointer;">
              <?php foreach ($produits as $data): ?>
              <?php $produit = new QstProduitDTO(); $produit = $data; ?>
              <tr>
                <td>
                  <button class="btn btn-warning" type="submit" title="Supprimer ce produit" data-toggle="tooltip"
                    onmousedown="removeProductFromTable(<?= $produit->pid; ?>);">
                    Supprimer
                  </button>
                </td>
                <td class="align-middle"><?= $produit->produitNom; ?></td>
                <td class="align-middle"><?= $produit->produitType; ?></td>
                <td class="align-middle"><?= $produit->produitDateDebut; ?></td>
                <td class="align-middle"><?= $produit->produitDateFin; ?></td>
                <td class="align-middle"><?= $produit->produitAupresConsomateurs; ?></td>
              </tr>  
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="row cet-qstprod-btnnav">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupprods-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupprods-nav').val('valider');">Valider ces informations</button>
        </div>
      </div>

      <input type="text" name="cetcal_session_id" id="cetcal_session_id" value="<?= $cetcal_session_id; ?>" hidden="hidden">
      <input type="text" name="qstprod-signupprods-nav" id="qstprod-signupprods-nav" value="unset" hidden="hidden">
      <input type="text" name="qstprod-signupprods-nav-pindex" id="qstprod-signupprods-nav-pindex" value="unset" hidden="hidden">
    </form>
  </div>
</div>

<!-- ------------------------------ -->
<!-- Specific js for this page only -->
<script src="/src/scripts/js/cetcal/cetcal.min.signupprods.js"></script>

<script type="text/javascript">
  function displayFicheProduit() {
    $('#cet-fiche-produit').toggle(400, 
      function() { 
        $('#cet-types-produits').toggle(400); 
      } 
    );
  }
</script>