<?php 
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupbesoins.dto.php');
$cetcal_session_id = htmlentities(htmlspecialchars($_GET['sitkn']));
session_id($cetcal_session_id);
session_start();
?>
<!-- singup besoins html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Nous avons besoin de connaitre vos besoins en matière de lieux de distribution, informatique, et d'autres sujets. Aidez nous en répondant aux questions ci-dessous.</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos fiches produits à tous moment.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form class="form" method="post" action="/src/app/controller/cet.qstprod.controller.signupbesoins.form.php">
      <label for="cdc-signup-email"> - Veuillez répondre aux questions ci-dessous :
        <small class="form-text cet-qstprod-label-text" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <label><small class="form-text cet-qstprod-label-text">Quelles seraient vos besoins par rapport à un annuaire hébergé par une plateforme informatique ?</small></label>
      <div class="cet-formgroup-container">
        <?php $counter = 0; ?>
        <?php foreach ($listes_arrays->besoins as $besoin): ?>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-<?= $counter; ?>" name="qstprod-besoins-<?= $counter; ?>">
          <label class="form-check-label cet-qstprod-label-text" for="qstprod-besoins-<?= $counter; ?>"><?= $besoin; ?></label>
        </div>
        <?php ++$counter; ?>
        <?php endforeach; ?>
      </div>

      <label class="cet-formgroup-container-label" for="qstprod-qstbesoinlibre"> 
        <small class="form-text cet-qstprod-label-text">Un besoin n'est pas présent dans la liste ci-dessus, exprimez vous :</small>
      </label>
      <div class="cet-formgroup-container">
        <div class="form-group mb-3"> 
          <label class="cet-input-label"><small class="cet-qstprod-label-text">Exprimez-vous sur vos attentes ! :</small></label>
          <textarea class="form-control" id="qstprod-qstbesoinlibre" name="qstprod-qstbesoinlibre" rows="3" placeholder="Exprimez-vous sur vos attentes !"></textarea>
        </div>
      </div>
      <!-- ------------------------ -->
      <!-- INPUTS formulaire STOP : -->      
      <!-- ------------------------ -->

      <div class="row cet-qstprod-btnnav">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupbesoins-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupbesoins-nav').val('valider');">Valider ces informations</button>
        </div>
      </div>

      <input type="text" name="cetcal_session_id" id="cetcal_session_id" value="<?= $cetcal_session_id; ?>" hidden="hidden">
      <input type="text" name="qstprod-signupbesoins-nav" id="qstprod-signupbesoins-nav" value="unset" hidden="hidden">
    </form>
  </div>
</div>