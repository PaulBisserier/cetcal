<?php
/** 
 * Arrays contenant toutes les entrées pour alimenter radios boutons ou checkboxs dans 
 * la couche vue. Données chargées depuis $_SERVER['DOCUMENT_ROOT']/res/data/
 */
 Class CetQstprodConstListes
 {
    public $activites = NULL;
    public $besoins = NULL;

    function __construct($fileReader)
    {
      $this->activites = $fileReader->read('cet.qstprod.liste.activites');
      $this->besoins = $fileReader->read('cet.qstprod.liste.besoins');
    }
 }
 ?>