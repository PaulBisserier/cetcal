<?php
// DTOs used here :
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupprods.dto.php');
// Prepare Session usage :
$cetcal_session_id = htmlentities(htmlspecialchars($_GET['sitkn']));
session_id($cetcal_session_id);
session_start();
$produits = isset($_SESSION['signupprods.form']) ? unserialize($_SESSION['signupprods.form']) : NULL; 
$recapProduitsDisplay = ($produits === NULL || count($produits) === 0) ? 'none' : 'block';
?>
<!-- singup produits html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez renseigner une fiche pour chaque produit.</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos fiches produits à tous moment.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form id="signupprods.form" class="form" method="post" 
      action="/src/app/controller/cet.qstprod.controller.signupprods.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner vos informations produits :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <div id="cet-types-produits">
        <label><small class="form-text text-muted">Dites-nous quels sont vos types de produits :</small></label>
        <div class="cet-formgroup-container">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="apiculteur" id="qstprod-ldist-ferme" 
            name="qstprod-ldist-qstgen[]">
            <label class="form-check-label text-muted" for="qstprod-ldist-ferme">
              <span class="badge badge-success">Apiculteur</span>
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="Type produit 2" id="qstprod-ldist-marches" 
            name="qstprod-ldist-qstgen[]">
            <label class="form-check-label text-muted" for="qstprod-ldist-marches">Type produit 2</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="Type produit 3" id="qstprod-ldist-magasins" 
            name="qstprod-ldist-qstgen[]">
            <label class="form-check-label text-muted" for="qstprod-ldist-magasins">Type produit 3</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="Type produit 4" id="qstprod-ldist-assos" 
            name="qstprod-ldist-qstgen[]">
            <label class="form-check-label text-muted" for="qstprod-ldist-assos">Type produit 4</label>
          </div>  

          <div class="row">
            <div class="col"> 
              <button type="button" class="btn btn-sm btn-success" style="float: right;"
                onclick="displayFicheProduit();">Saisir une fiche produit détaillé</button>
            </div>  
          </div>        
        </div>
      </div>

      <div id="cet-fiche-produit" style="display: none;">
        <label for="qstprod-nomprd"><small class="form-text text-muted">Renseignez la fiche produit, puis ajouter à la liste :</small></label>
        <div class="cet-formgroup-container">
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="text-muted">Nom du produit :</small></label>
            <input class="form-control is-invalid" id="qstprod-nomprd" name="qstprod-nomprd" 
              type="text" placeholder="Nom du produit, exemple : tomate"
              onblur="checkFormInputMin(30, 2, this.id);">
          </div>
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="text-muted">Type de produit :</small></label>
            <input class="form-control" id="qstprod-typeprd" name="qstprod-typeprd" type="text" 
              placeholder="Type de produit, exemple : marmande">
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6">
              <label><small class="form-text text-muted">Indiquer les dates de début et fin pour la saisonnalité de ce produit :</small></label>
            </div>
            <div class="form-group col-lg-3">
              <input type="text" class="form-control" id="qstprod-datedebut-saisonnaliteprd" 
                name="qstprod-datedebut-saisonnaliteprd" 
                onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date début">
            </div>
            <div class="form-group col-lg-3">
              <input type="text" class="form-control" id="qstprod-datefin-saisonnaliteprd" 
                name="qstprod-datefin-saisonnaliteprd" 
                onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date fin">
            </div>
          </div>
          <div class="form-group mb-3">
            <label class="cet-input-label"><small class="text-muted">Années d'expériences avec ce produit :</small></label>
            <input class="form-control is-invalid" id="qstprod-anneesxpprd" name="qstprod-anneesxpprd" 
              type="number" min="0" placeholder="Années d'expériences avec ce produit"
              onblur="checkFormInputInteger(3, 1, this.id);">
          </div>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="qstprod-labelpopprd">Auprès des consomateurs, ce produit est pour vous :</span>
            </div>
            <select class="form-control custom-select is-invalid" id="qstprod-popprd" 
              name="qstprod-popprd" aria-describedby="qstprod-labelpopprd" onblur="checkFormInputMin(30, 2, this.id);">
              <option></option>
              <option>populaire !</option>
              <option>difficile...</option>
              <option>à développer</option>
              <option>mon meilleur produit !</option>
              <option>un produit rare</option>
            </select>
          </div>  
          <div class="row">
            <div class="col"> 
              <button type="submit" class="btn btn-sm btn-success" style="float: right; margin-left: 3px;"
                onmousedown="$('#qstprod-signupprods-nav').val('ajouter');">Ajouter ce produit</button>
              <button type="button" class="btn btn-sm btn-primary" style="float: right;"
                onclick="displayFicheProduit();">Annuler</button>
            </div>  
          </div>
        </div>
      </div>
      
      <!-- ------------------------- -->
      <!-- ZONE de récap produits.   -->
      <!-- ------------------------- -->
      <div id="qstprod-table-produits" class="alert alert-success table-responsive" role="alert" 
        style="display: <?= $recapProduitsDisplay; ?>; margin-top: 20px;">
        <label> - Récapitulatif de vos fiches produits détaillées :</label>
        <div class="d-flex justify-content-center">
          <table class="table table-borderless table-striped table-hover">
            <thead class="thead-light">
              <tr>
                <th scope="col">Actions</th>
                <th scope="col">Nom</th>
                <th scope="col">Type</th>
                <th scope="col">Du,</th>
                <th scope="col">Au</th>
                <th scope="col">Expérience</th>
                <th scope="col">C'est un produit</th>
              </tr>
            </thead>
            <tbody style="cursor: pointer;">
              <?php foreach ($produits as $data): ?>
              <?php $produit = new QstProduitDTO(); $produit = $data; ?>
              <tr>
                <td>
                  <button class="btn btn-warning" type="submit" title="Supprimer ce produit" data-toggle="tooltip"
                    onmousedown="removeProductFromTable(<?= $produit->pid; ?>);">
                    Supprimer
                  </button>
                </td>
                <td class="align-middle"><?= $produit->produitNom; ?></td>
                <td class="align-middle"><?= $produit->produitType; ?></td>
                <td class="align-middle"><?= $produit->produitDateDebut; ?></td>
                <td class="align-middle"><?= $produit->produitDateFin; ?></td>
                <td class="align-middle"><?= $produit->produitAnneesExperience; ?> années</td>
                <td class="align-middle"><?= $produit->produitAupresConsomateurs; ?></td>
              </tr>  
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="row cet-qstprod-btnnav">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupprods-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupprods-nav').val('valider');">Valider ces informations</button>
        </div>
      </div>

      <input type="text" name="cetcal_session_id" id="cetcal_session_id" value="<?= $cetcal_session_id; ?>" hidden="hidden">
      <input type="text" name="qstprod-signupprods-nav" id="qstprod-signupprods-nav" value="unset" hidden="hidden">
      <input type="text" name="qstprod-signupprods-nav-pindex" id="qstprod-signupprods-nav-pindex" value="unset" hidden="hidden">
    </form>
  </div>
</div>

<!-- ------------------------------ -->
<!-- Specific js for this page only -->
<script src="/src/scripts/js/cetcal/cetcal.min.signupprods.js"></script>

<script type="text/javascript">
  function displayFicheProduit() {
    $('#cet-fiche-produit').toggle(400, 
      function() { 
        $('#cet-types-produits').toggle(400); 
      } 
    );
  }
</script>