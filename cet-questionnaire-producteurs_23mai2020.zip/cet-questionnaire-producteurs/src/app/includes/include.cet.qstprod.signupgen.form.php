<!-- singup general informations html form -->
<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>
        [TEXTE BOUCHON / A MODIFIER] Veuillez renseigner les informations demandées. Toutes les informations saisies sur cetcal.site vous appartiennent et à tout moment il vous sera possible de les supprimer.
      </p>
      <p>
        Les données entourées en rouge sont obligatoires. [TEXTE BOUCHON / A MODIFIER]
      </p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
  <div class="col-sm-3"></div>
</div>

<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <form class="form" action="/src/app/controller/cet.qstprod.controller.signupgen.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner les information demandées ci-dessous :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <div class="cet-formgroup-container">
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-nom" name="qstprod-nom" type="text" placeholder="Nom de famille" maxlength="30">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-prenom" name="qstprod-prenom" type="text" placeholder="Prénom">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-email" name="qstprod-email" type="text" placeholder="Adresse email" 
            onblur="checkValidEmail(60, this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-email-conf" name="qstprod-email-conf" type="text" placeholder="Confirmation adresse email"
            onblur="checkValidEmailConfirmation(60, 'qstprod-email', this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-mdp" name="qstprod-mdp" type="password" placeholder="Mot de passe de connexion à l'annuaire"
            onblur="checkFormInputMin(30, 8, this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-mdpconf" name="qstprod-mdpconf" type="password" placeholder="Confirmer votre mot de passe"
            onblur="checkMotsDePasse(30, 8, 'qstprod-mdp', this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-numbtel-fix" name="qstprod-numbtel-fix" type="text" maxlength="10" placeholder="N° de téléphone fix.">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-numbtel-port" name="qstprod-numbtel-port" type="text" maxlength="10" placeholder="N° de téléphone mobile.">
        </div>
      </div>
      
      <label class="cet-formgroup-container-label" for="qstprod-nomferme"><small class="form-text text-muted">Renseignez vos informations d'adresse d'exploitation :</small></label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-nomferme" name="qstprod-nomferme" type="text" placeholder="Nom commercial de la ferme">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-siret" name="qstprod-siret" type="text" maxlength="14" 
            minlength="14" placeholder="Siret" onblur="checkSiret(this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-numvoie" name="qstprod-numvoie" type="text" placeholder="Numéro sur voirie"
            onblur="checkFormInputInteger(10, 1, this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-rue" name="qstprod-rue" type="text" placeholder="Nom de la rue, chemin, avenue..."
            onblur="checkFormInput(60, this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-lieudit" name="qstprod-lieudit" type="text" placeholder="Lieu dit">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-commune" name="qstprod-commune" type="text" placeholder="Commune"
            onblur="checkFormInput(60, this.id);">
        </div>
        <div class="input-group mb-3">
          <input class="form-control is-invalid" id="qstprod-cp" name="qstprod-cp" type="text" maxlength="5" placeholder="Code postal"
            onblur="checkFormInputInteger(9, 4, this.id);">
        </div>
        <div class="input-group mb-3">  
          <input class="form-control" id="qstprod-cmpladrs" name="qstprod-cmpladrs" type="text" placeholder="Complément d'adresse">
        </div>
      </div>

      <label class="cet-formgroup-container-label" for="qstprod-www"><small class="form-text text-muted">Informations web et réseaux sociaux :</small></label> 
      <div class="cet-formgroup-container">
        <div class="input-group mb-3"> 
          <input class="form-control" id="qstprod-fb" name="qstprod-fb" type="text" placeholder="Page Facebook de la ferme (si existant)">
        </div>
        <div class="input-group mb-3">   
          <input class="form-control" id="qstprod-ig" name="qstprod-ig" type="text" placeholder="Page Instagram de la ferme (si existant)">
        </div>
        <div class="input-group mb-3">   
          <input class="form-control" id="qstprod-twitter" name="qstprod-twitter" type="text" placeholder="Compte Twitter de la ferme (si existant)">
        </div>
      
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-www" name="qstprod-www" type="text" placeholder="Site internet de votre exploitation (si existant)">
          <div class="input-group-append">
            <button class="btn btn-outline-primary" type="button">Vérifier l'adresse web</button>
          </div>
        </div>
        <div class="input-group mb-3">
          <input class="form-control" id="qstprod-adrwebboutiqueenligne" name="qstprod-adrwebboutiqueenligne" type="text" placeholder="Adresse web de boutique en ligne">
          <div class="input-group-append">
            <button class="btn btn-outline-primary" type="button">Vérifier l'adresse web</button>
          </div>
        </div>
      </div>

      <label class="cet-formgroup-container-label" for="qstprod-anneeinstall"><small class="form-text text-muted">Informations relatives à l'exploitation :</small></label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3"> 
          <input class="form-control" id="qstprod-anneeinstall" name="qstprod-anneeinstall" type="text" onfocus="(this.type='date')" 
          onblur="(this.type='text')" placeholder="Date d'installation de l'exploitation agricole">
        </div>
        <div class="input-group mb-3">   
          <input class="form-control" id="qstprod-syndc" name="qstprod-syndc" type="text" placeholder="Associations professionnelles et/ou syndicales dont vous êtes adhérent">
        </div>
        <div class="input-group mb-3"> 
          <input class="form-control" id="qstprod-orgcertifbio" name="qstprod-orgcertifbio" type="text" placeholder="Organisme certificateur BIO">
        </div>
        <div class="input-group mb-3"> 
          <input class="form-control" id="qstprod-typeprod" name="qstprod-typeprod" type="text" placeholder="Type de production">
        </div>
        <div class="input-group mb-3">   
          <input class="form-control" id="qstprod-surfacepc" name="qstprod-surfacepc" type="number" min="0.1"
            step="0.1" placeholder="Superficie cultivée plein champ en hectares">
        </div>
        <div class="input-group mb-3"> 
          <input class="form-control" id="qstprod-supserre" name="qstprod-supserre" type="number" min="0.1"
            step="0.1" placeholder="Superficie de culture serre en hectares">
        </div>
      </div>

      <label class="cet-formgroup-container-label"><small class="form-text text-muted">D'une manière générale, quels sont vos lieux/organismes de distribution ?</small></label>
      <div class="cet-formgroup-container">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-ferme" name="qstprod-ldist-ferme">
          <label class="form-check-label text-muted" for="qstprod-ldist-ferme">Directement à la ferme.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-marches" name="qstprod-ldist-marches">
          <label class="form-check-label text-muted" for="qstprod-ldist-marches">Marché(s) locaux.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-magasins" name="qstprod-ldist-magasins">
          <label class="form-check-label text-muted" for="qstprod-ldist-magasins">Magasins, boutiques.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-assos" name="qstprod-ldist-assos">
          <label class="form-check-label text-muted" for="qstprod-ldist-assos">Associations et/ou groupements.</label>
        </div>
      </div>

      <label class="cet-formgroup-container-label"><small class="form-text text-muted">Quelles seraient vos besoins par rapport à un annuaire hébergé par une plateforme informatique ?</small></label>
      <div class="cet-formgroup-container">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-1" name="qstprod-besoins-1">
          <label class="form-check-label text-muted" for="qstprod-besoins-1">Une page de présentation faisant office de site Internet pour votre ferme.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-2" name="qstprod-besoins-2">
          <label class="form-check-label text-muted" for="qstprod-besoins-2">Un moyen de se faire connaître.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-3" name="qstprod-besoins-3">
          <label class="form-check-label text-muted" for="qstprod-besoins-3">La possibilité d'y commercialiser directement mes produits.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-4" name="qstprod-besoins-4">
          <label class="form-check-label text-muted" for="qstprod-besoins-4">Un outil qui facilite les relations producteurs/consommateurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-5" name="qstprod-besoins-5">
          <label class="form-check-label text-muted" for="qstprod-besoins-5">Un outil qui facilite la mise en réseau entre producteurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-6" name="qstprod-besoins-6">
          <label class="form-check-label text-muted" for="qstprod-besoins-6">Un outil pour donner de l'information sur la bio aux consommateurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-7" name="qstprod-besoins-7">
          <label class="form-check-label text-muted" for="qstprod-besoins-7">Un outil qui aide à l'installation de nouveaux producteurs bio.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-8" name="qstprod-besoins-8">
          <label class="form-check-label text-muted" for="qstprod-besoins-8">Un outil pour organiser un « lobby bio » entre producteurs, consommateurs, élus engagés, associations...</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-9" name="qstprod-besoins-9">
          <label class="form-check-label text-muted" for="qstprod-besoins-9">Un outil interactif qui fait circuler de l'information entre les consommateurs et les différents acteurs du bio.</label>
        </div>
      </div>

      <label class="cet-formgroup-container-label" for="qstprod-qstbesoinlibre"><small class="form-text text-muted">Un besoin n'est pas présent dans la liste ci-dessus, exprimez vous :</small></label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3"> 
          <textarea class="form-control" id="qstprod-qstbesoinlibre" name="qstprod-qstbesoinlibre" rows="3" placeholder="Exprimez-vous sur vos attentes !"></textarea>
        </div>
      </div>
      <!-- ------------------------ -->
      <!-- INPUTS formulaire STOP : -->      
      <!-- ------------------------ -->

      <div class="row" style="margin-top: 20px;">
        <div class="col text-center">
          <button class="btn btn-primary">
            Retour accueil
          </button>
          <button class="btn btn-primary" type="submit">
            Valider ces informations
          </button>
        </div>
      </div>

    </form>
  </div>
  <div class="col-sm-3"></div>
</div>

<script type="text/javascript">
  function checkFormInput(maxl, id) {
    var l = $('#' + id).val().length;
    if (l > 1 && l <= maxl) { 
      displayValidFormInput(id);
    } else { 
      displayInvalidFormInput(id); 
    }
    return;
  }

  function checkFormInputInteger(maxl, minl, id) {
    var l = $('#' + id).val().length;
    if ((l >= minl && l <= maxl) && $.isNumeric($('#' + id).val())) { 
      displayValidFormInput(id);
    } else { 
      displayInvalidFormInput(id); 
    }
    return;
  }

  function checkFormInputMin(maxl, minl, id) {
    var l = $('#' + id).val().length;
    if (l > 1 && l <= maxl && l >= minl) { 
      displayValidFormInput(id);
    } else { 
      displayInvalidFormInput(id); 
    }
    return;
  }

  function checkSiret(id) {
    var l = $('#' + id).val().length;
    if (l === 14 && $.isNumeric($('#' + id).val())) { 
      displayValidFormInput(id);
    } else { 
      displayInvalidFormInput(id);
      if (l > 0) {
        $('#modal-questionaire-titre').text('N° de SIRET invalid');
        $('#modal-questionaire-paragraphe').text("Le siret saisie n'est pas un siret valide. Un Siret comporte 14 chiffres et aucune lettre ou caractère. Veuillez rectifier votre saisie.");
        $('#modal-questionaire-btn-primary').text("J'ai compris");
        $('#modal-questionaire-btn').click(); 
      }
    }
    return; 
  }

  function checkMotsDePasse(maxl, minl, id, idconf) {
    if ($('#' + id).val() != $('#' + idconf).val()) {
      displayInvalidFormInput(idconf);
      $('#modal-questionaire-titre').text('Mots de passe non identiques');
      $('#modal-questionaire-paragraphe').text("Le mot de passe de confirmation de correspond pas au mot de passe saisie. Veuillez vérifier vos saisies.");
      $('#modal-questionaire-btn-primary').text("J'ai compris");
      $('#modal-questionaire-btn').click();
      return;
    } else {
      checkFormInputMin(maxl, minl, idconf);
    }
  }

  function checkValidEmail(maxl, id) {
    var l = $('#' + id).val().length;
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (regex.test($('#' + id).val()) && l <= maxl) {
      displayValidFormInput(id);
    } else {
      displayInvalidFormInput(id);
    } 
  }

  function checkValidEmailConfirmation(maxl, id, idconf) {
    if (($('#' + idconf).val().length > 2 && $('#' + id).val().length > 2) && $('#' + id).val() != $('#' + idconf).val()) {
      displayInvalidFormInput(idconf);
      $('#modal-questionaire-titre').text('E-mails non identiques');
      $('#modal-questionaire-paragraphe').text("L'e-mail de confirmation de correspond pas à l'e-mail saisie. Veuillez vérifier vos saisies.");
      $('#modal-questionaire-btn-primary').text("J'ai compris");
      $('#modal-questionaire-btn').click();
      return;
    } else {
      checkValidEmail(maxl, idconf);
    }
  }

  function displayInvalidFormInput(id) {
    $('#' + id).removeClass('is-valid');
    $('#' + id).addClass('is-invalid'); 
  }

  function displayValidFormInput(id) {
    $('#' + id).removeClass('is-invalid');
    $('#' + id).addClass('is-valid'); 
  }
</script>