<?php 
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupbesoins.dto.php');
$cetcal_session_id = htmlentities(htmlspecialchars($_GET['sitkn']));
session_id($cetcal_session_id);
session_start();
?>
<!-- singup besoins html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Nous avons besoin de connaitre vos besoins en matière de lieux de distribution, informatique, et d'autres sujets. Aidez nous en répondant aux questions ci-dessous.</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos fiches produits à tous moment.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form class="form" method="post" action="/src/app/controller/cet.qstprod.controller.signupbesoins.form.php">
      <label for="cdc-signup-email"> - Veuillez répondre aux questions ci-dessous :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <label><small class="form-text text-muted">D'une manière générale, quels sont vos lieux/organismes de distribution ?</small></label>
      <div class="cet-formgroup-container">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Directement à la ferme" id="qstprod-ldist-ferme" 
          name="qstprod-ldist-qstgen[]">
          <label class="form-check-label text-muted" for="qstprod-ldist-ferme">Directement à la ferme.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Marché(s) locaux" id="qstprod-ldist-marches" 
          name="qstprod-ldist-qstgen[]">
          <label class="form-check-label text-muted" for="qstprod-ldist-marches">Marché(s) locaux.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Magasins, boutiques" id="qstprod-ldist-magasins" 
          name="qstprod-ldist-qstgen[]">
          <label class="form-check-label text-muted" for="qstprod-ldist-magasins">Magasins, boutiques.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Associations et/ou groupements" id="qstprod-ldist-assos" 
          name="qstprod-ldist-qstgen[]">
          <label class="form-check-label text-muted" for="qstprod-ldist-assos">Associations et/ou groupements.</label>
        </div>
      </div>

      <label class="cet-formgroup-container-label"><small class="form-text text-muted">Quelles seraient vos besoins par rapport à un annuaire hébergé par une plateforme informatique ?</small></label>
      <div class="cet-formgroup-container">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-1" name="qstprod-besoins-1">
          <label class="form-check-label text-muted" for="qstprod-besoins-1">Une page de présentation faisant office de site Internet pour votre ferme.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-2" name="qstprod-besoins-2">
          <label class="form-check-label text-muted" for="qstprod-besoins-2">Un moyen de se faire connaître.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-3" name="qstprod-besoins-3">
          <label class="form-check-label text-muted" for="qstprod-besoins-3">La possibilité d'y commercialiser directement mes produits.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-4" name="qstprod-besoins-4">
          <label class="form-check-label text-muted" for="qstprod-besoins-4">Un outil qui facilite les relations producteurs/consommateurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-5" name="qstprod-besoins-5">
          <label class="form-check-label text-muted" for="qstprod-besoins-5">Un outil qui facilite la mise en réseau entre producteurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-6" name="qstprod-besoins-6">
          <label class="form-check-label text-muted" for="qstprod-besoins-6">Un outil pour donner de l'information sur la bio aux consommateurs.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-7" name="qstprod-besoins-7">
          <label class="form-check-label text-muted" for="qstprod-besoins-7">Un outil qui aide à l'installation de nouveaux producteurs bio.</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-8" name="qstprod-besoins-8">
          <label class="form-check-label text-muted" for="qstprod-besoins-8">Un outil pour organiser un « lobby bio » entre producteurs, consommateurs, élus engagés, associations...</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-9" name="qstprod-besoins-9">
          <label class="form-check-label text-muted" for="qstprod-besoins-9">Un outil interactif qui fait circuler de l'information entre les consommateurs et les différents acteurs du bio.</label>
        </div>
      </div>

      <label class="cet-formgroup-container-label" for="qstprod-qstbesoinlibre"> 
        <small class="form-text text-muted">Un besoin n'est pas présent dans la liste ci-dessus, exprimez vous :</small>
      </label>
      <div class="cet-formgroup-container">
        <div class="form-group mb-3"> 
          <label class="cet-input-label"><small class="text-muted">Exprimez-vous sur vos attentes ! :</small></label>
          <textarea class="form-control" id="qstprod-qstbesoinlibre" name="qstprod-qstbesoinlibre" rows="3" placeholder="Exprimez-vous sur vos attentes !"></textarea>
        </div>
      </div>
      <!-- ------------------------ -->
      <!-- INPUTS formulaire STOP : -->      
      <!-- ------------------------ -->

      <div class="row cet-qstprod-btnnav">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupbesoins-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onmousedown="$('#qstprod-signupbesoins-nav').val('valider');">Valider ces informations</button>
        </div>
      </div>

      <input type="text" name="cetcal_session_id" id="cetcal_session_id" value="<?= $cetcal_session_id; ?>" hidden="hidden">
      <input type="text" name="qstprod-signupbesoins-nav" id="qstprod-signupbesoins-nav" value="unset" hidden="hidden">
    </form>
  </div>
</div>