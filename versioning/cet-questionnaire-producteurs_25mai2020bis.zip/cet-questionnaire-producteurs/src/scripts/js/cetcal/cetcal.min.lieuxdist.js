function appendToTBody_lieuxdist(tableId, nom, dates, periodicite) {
	var html = '<tr><td>' + $('#' + nom).val() + '</td>';
	html += '<td>' + $('#' + dates).val() + '</td>';
	html += '<td>' + $('#' + periodicite).val() + ' /mois</td></tr>';
	$("#" + tableId + " tbody").append(html);
	$('#' + nom).val('');
	$('#' + dates).val('');
	$('#' + periodicite).val('');
	$("#" + tableId).css('display', 'block');
	$('#' + nom).focus();
}