function appendToTBody_produits(tableId, nom, type, datedeb, datefin, prix, anneesprd) {
      var html = '<tr><td>' + $('#' + nom).val() + '</td>';
      html += '<td>' + $('#' + type).val() + '</td>';
      html += '<td>' + $('#' + datedeb).val() + '</td>';
      html += '<td>' + $('#' + datefin).val() + '</td>';
      html += '<td>' + $('#' + anneesprd).val() + ' années</td></tr>';
      $("#" + tableId + " tbody").append(html);
      $('#' + nom).val('');
      $('#' + type).val('');
      $('#' + datedeb).val('');
      $('#' + datefin).val('');
      $('#' + prix).val('');
      $('#' + anneesprd).val('');
      $("#" + tableId).css('display', 'block');
      $('#' + nom).focus();
}