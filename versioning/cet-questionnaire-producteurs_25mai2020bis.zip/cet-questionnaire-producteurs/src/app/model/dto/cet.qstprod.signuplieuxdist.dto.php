<?php
/** 
 * signuplieuxdist.form html form DTO.
 */
Class QstLieuxDistributionDTO
{

  public $lieuxNom;
  public $jourLivraison;
  public $periodiciteLivraison;

  function __construct($pLieuxNom = "", $pJourLivraison = "", $pPeriodiciteLivraison = "")
  {
    $this->produitNom = $pLieuxNom;
    $this->produitType = $pJourLivraison;
    $this->produitDateDebut = $pPeriodiciteLivraison;
  }

}