<!-- login html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>
        [TEXTE BOUCHON / A MODIFIER] Afin de pouvoir modifier ou créer des entrées dans l'annuaire, il faut être inscrit. Si déjà inscrit, connectez-vous. Sinon, créer un compte en deux clics pour pouvoir renseigner les informations nécessaire au référencement dans l'annuaire. Toutes les informations saisies vous appartiennent et à tous moment il vous sera possible de les supprimer pour une raison qui vous est pertinente. Vous êtes producteur et vous souhaitez vous inscrire pour être référencé dans l'annuaire : <a href="/src/app/controller/cet.qstprod.controller.login.form.php">cliquez ici</a> [TEXTE BOUCHON / A MODIFIER]
      </p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>
<div class="row justify-content-lg-center">
  <div class="col-lg-6"> 
    <form class="form" action="/src/app/controller/cet.qstprod.controller.login.form.php" method="post">
      <label for="qstprod-email"> - Veuillez renseigner votre identifiant et mot de passe :</label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3">
          <input class="form-control" name="qstprod-email" id="qstprod-email" type="text" placeholder="Email, n°de téléphone ou identifiant" aria-label="email ou identifiant">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" name="qstprod-motdepasse" id="qstprod-motdepasse" type="password" placeholder="Mot de passe" aria-label="Mot de passe">
        </div>
        <button class="btn btn-primary btn-block" type="submit" style="margin-top: 8px;">Se connecter</button>
      </div>
      <small class="form-text text-muted" style="margin-top: 12px;">
        <a href="#"> - J'ai oublié mon mot de passe.</a><br>
        <a href="#"> - J'ai perdu mon identifiant de connexion.</a><br>
        <a href="/src/app/controller/cet.qstprod.controller.login.form.php"> - Producteur, je souhaite m'inscrire et être référencé.</a></small>  
    </form>
  </div>
</div>