<?php 
session_start();
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupgen.dto.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupprods.dto.php');
$data = new QstProdGeneraleDTO();
$data = isset($_SESSION['signupgen.form']) ? unserialize($_SESSION['signupgen.form']) : NULL; 
$produits = new QstProduitDTO();
$produits = isset($_SESSION['signupprods.form']) ? unserialize($_SESSION['signupprods.form']) : NULL;
?>
<!-- singup lieux de distribution informations html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez vérifier le récapitulatif de vos informations.</p>
      <p>Vous avez la possibilité de revenir modifier vos informations à l'aide des boutons Retour présents sur toutes les pages. Si après relecture, le récapitulatif ci-dessous est correct, veuillez finaliser votre inscription.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>

<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <form class="form" method="post" action="/src/app/controller/cet.qstprod.controller.signuprecap.form.php">

      <div class="row" style="margin-top: 20px;">
        <div class="col text-center">
          <button class="btn btn-primary" type="submit" onfocus="$('#qstprod-signuprecap-nav').val('retour');">Retour</button>
          <button class="btn btn-primary" type="submit" onfocus="$('#qstprod-signuprecap-nav').val('valider');">Valider votre inscription</button>
        </div>
      </div>

      <input type="text" name="qstprod-signuprecap-nav" id="qstprod-signuprecap-nav" value="unset" hidden="hidden">
    </form>
  </div>
</div>