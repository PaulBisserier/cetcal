<?php 
// SESSION start for data storage.
session_start();
// Prepare navigation :
$nav = htmlspecialchars($_POST['qstprod-signuplieuxdist-nav']);
if ($nav != 'valider' && $nav != 'retour') { /*Error de navigation TODO.*/ $nav = 'retour'; }
$status = $nav == 'valider' ? 'signuprecap.form' : 'signupprods.form';
$whitelist = ['127.0.0.1', '::1', 'localhost'];
$localhost = in_array($_SERVER['REMOTE_ADDR'], $whitelist);

// POST form logic :

// Apply navigation :
$localhost ? header('Location: /?status='.$status) : header('Location: /?status='.$status);
exit();
?>