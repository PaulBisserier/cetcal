<?php 
// SESSION start for data storage.
session_start();
// Prepare navigation :
$nav = htmlspecialchars($_POST['qstprod-signupprods-nav']);
$update = false;
if ($nav != 'valider' && $nav != 'retour' && $nav != 'miseajour') 
{ 
  /*Error de navigation TODO.*/ 
  $nav = 'retour';
}
$update = $nav == 'miseajour';
$status = ($update == true) ? 'signupprods.form' : ($nav == 'valider' ? 'signuplieuxdist.form' : 'signupgen.form');

/* *****************************************************************************/
/* HTTP POST : var setup : *****************************************************/
// POST form logic - dans l'ordre du formulaire HTML :
if ($update) 
{
  require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/utils/cet.qstprod.utils.httpdataprocessor.php');
  $dataProcessor = new HTTPDataProcessor();
  $form_pnom = $dataProcessor->processHttpFormData($_POST['qstprod-nomprd']);
  $form_ptype = $dataProcessor->processHttpFormData($_POST['qstprod-typeprd']);
  $form_pdatedeb = $dataProcessor->processHttpFormData($_POST['qstprod-datedebut-saisonnaliteprd']);
  $form_pdatefin = $dataProcessor->processHttpFormData($_POST['qstprod-datefin-saisonnaliteprd']);
  $form_annees_experience = $dataProcessor->processHttpFormData($_POST['qstprod-anneesxpprd']);
  $form_aupres_consomateurs = $dataProcessor->processHttpFormData($_POST['qstprod-popprd']);

  require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupprods.dto.php');
  $dtoProdProduits = new QstProduitDTO($form_pnom, $form_ptype, $form_pdatedeb, $form_pdatefin, 
    $form_annees_experience, $form_aupres_consomateurs);
  $fichesProduits = isset($_SESSION['signupprods.form']) ? unserialize($_SESSION['signupprods.form']) : array();

  array_push($fichesProduits, $dtoProdProduits);
  $_SESSION['signupprods.form'] = serialize($fichesProduits);
}
/* *****************************************************************************/

// Apply navigation :
header('Location: /?status='.$status);
exit();
?>