<?php
$DOC_ROOT = $_SERVER['DOCUMENT_ROOT'];
$PHP_INCLUDES_PATH = $DOC_ROOT.'/src/app/includes/';
$PHP_CONTROLLER_PATH = $DOC_ROOT.'/src/app/controller/';
include $PHP_CONTROLLER_PATH.'cet.qstprod.controller.index.php';
$status = htmlspecialchars(isset($_GET['status']) && !empty($_GET['status']) ? $_GET['status'] : 'login.form');
?>

<!-- -->
<!DOCTYPE html>
<html lang="fr"><head>
  <!--<base href="https://www.cet-qstprod.com/" />-->
  <title></title>
  <meta name="description" content="............"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <META HTTP-EQUIV="Expires" CONTENT="-1">
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
  <link rel="stylesheet" href="/src/scripts/css/bootstrap.min.css">
  <script src="/src/scripts/js/jquery/jquery-3.4.1.min.js"></script>
  <script src="/src/scripts/js/bootstrap.min.js"></script>
</head>
<body onload="// do this or that...">
  <?php 
    include $PHP_INCLUDES_PATH.'include.cet.qstprod.navbar.php'; 
    include $PHP_INCLUDES_PATH.'include.cet.qstprod.'.$status.'.php';
  ?>
</body>
</html>

  <style type="text/css">
    .form { margin-bottom: 60px; }
  </style>