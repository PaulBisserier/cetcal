<?php 
$status = 'signupprods.form';
$whitelist = ['127.0.0.1', '::1', 'localhost'];
$localhost = in_array($_SERVER['REMOTE_ADDR'], $whitelist);
$localhost ? header('Location: /?status='.$status) : header('Location: /?status='.$status);
exit();
?>