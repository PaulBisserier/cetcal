<!-- singup lieux de distribution informations html form -->
<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez renseigner une fiche pour chaque lieux de distribution</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos informations de lieux de distribution.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
  <div class="col-sm-3"></div>
</div>

<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <form class="form" action="/src/app/controller/cet.qstprod.controller.signuplieuxdist.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner vos lieux de distribution :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <br>
      <label for="qstprod-nomlieuxdist"><small class="form-text text-muted">Renseignez un lieux de distribution, puis ajouter à la liste :</small></label>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-nomlieuxdist" name="qstprod-nomlieuxdist" type="text" placeholder="Nom du lieux de distribution">
      </div>
      <div class="input-group mb-3">  
        <input class="form-control" id="qstprod-datelieuxdist" name="qstprod-datelieuxdist" type="text" 
        onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Journée/date approximative de livraison">
      </div>
      <div class="input-group mb-3">  
        <input class="form-control" id="qstprod-periodicitedist" name="qstprod-periodicitedist" type="number" 
          max="30" placeholder="Périodicité de distribution mensuelle">
      </div>
      
      <div class="row">
        <div class="col"> 
          <button type="button" class="btn btn-sm btn-primary" style="float: right;" onclick="appendToTBody('qstprod-table-lieuxdist', 'qstprod-nomlieuxdist', 'qstprod-datelieuxdist', 'qstprod-periodicitedist');">
            Ajouter ce lieux de distribution
          </button>
        </div>
      </div>

      <!-- ------------------------- -->
      <!-- ZONE de récap produits.   -->
      <!-- ------------------------- -->
      <div id="qstprod-table-lieuxdist" class="alert alert-secondary" role="alert" style="display: none; margin-top: 20px;">
        <label> - Récapitulatif de vos lieux de distribution :</label>
        <div class="d-flex justify-content-center">
          <table class="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">lieux de distribution</th>
                <th scope="col">Journée/date</th>
                <th scope="col">Périodicité/mois</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>

      <div class="row" style="margin-top: 12px;">
        <div class="col text-center">
          <button class="btn btn-primary">Retour</button>
          <button class="btn btn-primary" type="submit">Valider ces informations</button>
        </div>
      </div>

    </form>
    </div>
  <div class="col-sm-3"></div>  
</div>

  <script type="text/javascript">
    function appendToTBody(tableId, nom, dates, periodicite) {
      var html = '<tr><th scope="row"></th>';
      html += '<td>' + $('#' + nom).val() + '</td>';
      html += '<td>' + $('#' + dates).val() + '</td>';
      html += '<td>' + $('#' + periodicite).val() + '</td></tr>';
      $("#" + tableId + " tbody").append(html);
      $('#' + nom).val('');
      $('#' + dates).val('');
      $('#' + periodicite).val('');
      $("#" + tableId).css('display', 'block');
      $('#' + nom).focus();
    }
  </script>