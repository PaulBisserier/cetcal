<!-- singup produits informations html form -->
<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez renseigner une fiche pour chaque produit.</p>
      <p>Après inscription, vous avez la possibilité d'enrichir vos fiches produits à tous moment.</p>
      <p>Toutes les informations saisies sur annuaire-bio.org vous appartiennent.</p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
  <div class="col-sm-3"></div>
</div>

<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <form class="form" action="/src/app/controller/cet.qstprod.controller.signupprods.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner vos information produits :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <br>
      <label for="qstprod-nomprd"><small class="form-text text-muted">Renseignez la fiche produit, puis ajouter à la liste :</small></label>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-nomprd" name="qstprod-nomprd" type="text" placeholder="Nom du produit, exemple : tomate">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-typeprd" name="qstprod-typeprd" type="text" placeholder="Type de produit, exemple : marmande">
      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label><small class="form-text text-muted">Indiquer les dates de début et fin pour la saisonnalité de ce produit :</small></label>
        </div>
        <div class="form-group col-md-3">
          <input type="text" class="form-control" id="qstprod-datedebut-saisonnaliteprd" 
            onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date début">
        </div>
        <div class="form-group col-md-3">
          <input type="text" class="form-control" id="qstprod-datefin-saisonnaliteprd" 
            onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="Date fin">
        </div>
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-anneesxpprd" name="qstprod-anneesxpprd" type="number" placeholder="Années d'expériences avec ce produit">
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" id="qstprod-labelpopprd">Auprès des consomateurs, ce produit est pour vous :</span>
        </div>
        <select class="form-control" id="qstprod-popprd" name="qstprod-popprd" aria-describedby="qstprod-labelpopprd">
          <option></option>
          <option>populaire !</option>
          <option>difficile...</option>
          <option>à développer</option>
          <option>mon meilleur produit !</option>
          <option>un produit rare</option>
        </select>
      </div>
      <div class="row">
        <div class="col"> 
          <button type="button" class="btn btn-sm btn-primary" style="float: right;" 
            onclick="appendToTBody('qstprod-table-produits', 'qstprod-nomprd', 'qstprod-typeprd', 'qstprod-datedebut-saisonnaliteprd', 
            'qstprod-datefin-saisonnaliteprd', 'qstprod-prixkprd', 'qstprod-anneesxpprd');">Ajouter ce produit</button>
        </div>  
      </div>

      <!-- ------------------------- -->
      <!-- ZONE de récap produits.   -->
      <!-- ------------------------- -->
      <div id="qstprod-table-produits" class="alert alert-secondary" role="alert" style="display: none; margin-top: 20px;">
        <label> - Récapitulatif de vos fiches produits :</label>
        <div class="d-flex justify-content-center">
          <table class="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">Nom</th>
                <th scope="col">Type</th>
                <th scope="col">Du,</th>
                <th scope="col">Au</th>
                <th scope="col">Expérience</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>

      <div class="row" style="margin-top: 12px;">
        <div class="col text-center">
          <button class="btn btn-primary">Retour</button>
          <button class="btn btn-primary" type="submit">Valider ces informations</button>
        </div>
      </div>

    </form>
  </div>
  <div class="col-sm-3"></div>
</div>

  <script type="text/javascript">
    function appendToTBody(tableId, nom, type, datedeb, datefin, prix, anneesprd) {
      var html = '<tr><th scope="row"></th>';
      html += '<td>' + $('#' + nom).val() + '</td>';
      html += '<td>' + $('#' + type).val() + '</td>';
      html += '<td>' + $('#' + datedeb).val() + '</td>';
      html += '<td>' + $('#' + datefin).val() + '</td>';
      html += '<td>' + $('#' + anneesprd).val() + ' années</td></tr>';
      $("#" + tableId + " tbody").append(html);
      $('#' + nom).val('');
      $('#' + type).val('');
      $('#' + datedeb).val('');
      $('#' + datefin).val('');
      $('#' + prix).val('');
      $('#' + anneesprd).val('');
      $("#" + tableId).css('display', 'block');
      $('#' + nom).focus();
    }
  </script>