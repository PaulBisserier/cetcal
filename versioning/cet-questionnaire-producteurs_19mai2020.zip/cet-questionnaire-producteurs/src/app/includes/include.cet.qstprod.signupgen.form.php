<!-- singup general informations html form -->
<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>
        Veuillez renseigner les informations demandées. Toutes les informations saisies sur annuaire-bio.org vous appartiennent et à tous moment il vous sera possible de les supprimer pour une raison qui vous est pertinente.
      </p>
      <p>
        Les données marquées 
      </p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
  <div class="col-sm-3"></div>
</div>

<div class="row justify-content-md-center">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <form class="form" action="/src/app/controller/cet.qstprod.controller.signupgen.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner les information demandées ci-dessous :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="">
      ---- ------------------------- -->
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-nom" name="qstprod-nom" type="text" placeholder="Nom de famille">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-prenom" name="qstprod-prenom" type="text" placeholder="Prénom">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-email" name="qstprod-email" type="text" placeholder="Adresse email">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-email-conf" name="qstprod-email-conf" type="text" placeholder="Confirmation adresse email">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-mdp" name="qstprod-mdp" type="password" placeholder="Mot de passe de connexion à l'annuaire">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-mdpconf" name="qstprod-mdpconf" type="password" placeholder="Confirmer votre mot de passe">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-numbtel-fix" name="qstprod-numbtel-fix" type="text" maxlength="10" placeholder="N° de téléphone fix.">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-numbtel-port" name="qstprod-numbtel-port" type="text" maxlength="10" placeholder="N° de téléphone mobile.">
      </div>
      
      <label for="qstprod-nomferme"><small class="form-text text-muted">Renseignez vos informations d'adresse d'exploitation :</small></label>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-nomferme" name="qstprod-nomferme" type="text" placeholder="Nom commercial de la ferme">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-siret" name="qstprod-siret" type="text" placeholder="Siret">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-numvoie" name="qstprod-numvoie" type="text" placeholder="Numéro sur voirie">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-rue" name="qstprod-rue" type="text" placeholder="Nom de la rue, chemin, avenue...">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-lieudit" name="qstprod-lieudit" type="text" placeholder="Lieu dit">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-commune" name="qstprod-commune" type="text" placeholder="Commune">
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-cp" name="qstprod-cp" type="text" maxlength="5" placeholder="Code postal">
      </div>
      <div class="input-group mb-3">  
        <input class="form-control" id="qstprod-cmpladrs" name="qstprod-cmpladrs" type="text" placeholder="Complément d'adresse">
      </div>
      
      <label for="qstprod-www"><small class="form-text text-muted">Informations web et réseaux sociaux :</small></label>
      <div class="input-group mb-3"> 
        <input class="form-control" id="qstprod-fb" name="qstprod-fb" type="text" placeholder="Page Facebook de la ferme (si existant)">
      </div>
      <div class="input-group mb-3">   
        <input class="form-control" id="qstprod-ig" name="qstprod-ig" type="text" placeholder="Page Instagram de la ferme (si existant)">
      </div>
      <div class="input-group mb-3">   
        <input class="form-control" id="qstprod-twitter" name="qstprod-twitter" type="text" placeholder="Compte Twitter de la ferme (si existant)">
      </div>
      
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-www" name="qstprod-www" type="text" placeholder="Site internet de votre exploitation (si existant)">
        <div class="input-group-append">
          <button class="btn btn-outline-primary" type="button">Vérifier l'adresse web</button>
        </div>
      </div>
      <div class="input-group mb-3">
        <input class="form-control" id="qstprod-adrwebboutiqueenligne" name="qstprod-adrwebboutiqueenligne" type="text" placeholder="Adresse web de boutique en ligne">
        <div class="input-group-append">
          <button class="btn btn-outline-primary" type="button">Vérifier l'adresse web</button>
        </div>
      </div>

      <label for="qstprod-anneeinstall"><small class="form-text text-muted">Informations relatives à l'exploitation :</small></label>
      <div class="input-group mb-3"> 
        <input class="form-control" id="qstprod-anneeinstall" name="qstprod-anneeinstall" type="text" onfocus="(this.type='date')" 
        onblur="(this.type='text')" placeholder="Date d'installation de l'exploitation agricole">
      </div>
      <div class="input-group mb-3">   
        <input class="form-control" id="qstprod-syndc" name="qstprod-syndc" type="text" placeholder="Associations professionnelles et/ou syndicales dont vous êtes adhérent">
      </div>
      <div class="input-group mb-3"> 
        <input class="form-control" id="qstprod-orgcertifbio" name="qstprod-orgcertifbio" type="text" placeholder="Organisme certificateur BIO">
      </div>
      <div class="input-group mb-3"> 
        <input class="form-control" id="qstprod-typeprod" name="qstprod-typeprod" type="text" placeholder="Type de production">
      </div>
      <div class="input-group mb-3">   
        <input class="form-control" id="qstprod-surfacepc" name="qstprod-surfacepc" type="number" 
          step="0.1" placeholder="Superficie cultivée plein champ en hectares">
      </div>
      <div class="input-group mb-3"> 
        <input class="form-control" id="qstprod-supserre" name="qstprod-supserre" type="number" 
          step="0.1" placeholder="Superficie de culture serre en hectares">
      </div>

      <label><small class="form-text text-muted">De manière générale, quels sont vos lieux/organismes de distribution ?</small></label>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-ferme" name="qstprod-ldist-ferme">
        <label class="form-check-label text-muted" for="qstprod-ldist-ferme">Directement à la ferme.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-marches" name="qstprod-ldist-marches">
        <label class="form-check-label text-muted" for="qstprod-ldist-marches">Marché(s) locaux.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-magasins" name="qstprod-ldist-magasins">
        <label class="form-check-label text-muted" for="qstprod-ldist-magasins">Magasins, boutiques.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-assos" name="qstprod-ldist-assos">
        <label class="form-check-label text-muted" for="qstprod-ldist-assos">Associations et/ou groupements.</label>
      </div>

      <label><small class="form-text text-muted">Quelles seraient vos besoins par rapport à un annuaire hébergé par une plateforme informatique ?</small></label>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-1" name="qstprod-besoins-1">
        <label class="form-check-label text-muted" for="qstprod-besoins-1">Une page de présentation faisant office de site Internet pour votre ferme.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-2" name="qstprod-besoins-2">
        <label class="form-check-label text-muted" for="qstprod-besoins-2">Un moyen de se faire connaître.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-3" name="qstprod-besoins-3">
        <label class="form-check-label text-muted" for="qstprod-besoins-3">La possibilité d'y commercialiser directement mes produits.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-4" name="qstprod-besoins-4">
        <label class="form-check-label text-muted" for="qstprod-besoins-4">Un outil qui facilite les relations producteurs/consommateurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-5" name="qstprod-besoins-5">
        <label class="form-check-label text-muted" for="qstprod-besoins-5">Un outil qui facilite la mise en réseau entre producteurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-6" name="qstprod-besoins-6">
        <label class="form-check-label text-muted" for="qstprod-besoins-6">Un outil pour donner de l'information sur la bio aux consommateurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-7" name="qstprod-besoins-7">
        <label class="form-check-label text-muted" for="qstprod-besoins-7">Un outil qui aide à l'installation de nouveaux producteurs bio.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-8" name="qstprod-besoins-8">
        <label class="form-check-label text-muted" for="qstprod-besoins-8">Un outil pour organiser un « lobby bio » entre producteurs, consommateurs, élus engagés, associations...</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-9" name="qstprod-besoins-9">
        <label class="form-check-label text-muted" for="qstprod-besoins-9">Un outil interactif qui fait circuler de l'information entre les consommateurs et les différents acteurs du bio.</label>
      </div>

      <br>
      <label for="qstprod-qstbesoinlibre"><small class="form-text text-muted">Un besoin n'est pas présent dans la liste ci-dessus, exprimez vous :</small></label>
      <div class="input-group mb-3"> 
        <textarea class="form-control" id="qstprod-qstbesoinlibre" name="qstprod-qstbesoinlibre" rows="3" placeholder="Exprimez-vous sur vos attentes !"></textarea>
      </div>
      <!-- ------------------------ -->
      <!-- INPUTS formulaire STOP : -->      
      <!-- ------------------------ -->

      <div class="row" style="margin-top: 12px;">
        <div class="col text-center">
          <button class="btn btn-primary">
            Retour accueil
          </button>
          <button class="btn btn-primary" type="submit">
            Valider ces informations
          </button>
        </div>
      </div>

    </form>
  </div>
  <div class="col-sm-3"></div>
</div>