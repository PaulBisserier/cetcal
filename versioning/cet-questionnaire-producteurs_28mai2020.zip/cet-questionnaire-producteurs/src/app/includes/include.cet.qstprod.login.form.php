<!-- login html form -->
<div class="row justify-content-lg-center">
  <div class="col-lg-6">
    <div class="alert alert-info fade show" role="alert">
      <p>
        [OBJECTIF-1 de cette zone de texte] informer sur les deux options, à savoir se connecter pour modifier les données ou s'inscrire pour ensuite bénéficier de toutes les fonctionnalités.[OBJECTIF de cette zone de texte]
      </p>
      <p>
        [OBJECTIF-2 de cette zone de texte] informer et rassurer sur nos conditions légales en matière de droit numérique. A savoir : le producteur reste souverain de ces données (supression, mise à jour), aucun profit ne sera fait sur la base des données producteur (pas de pub, pas de revente des données).[OBJECTIF de cette zone de texte] 
      </p>
      <p>
        [TEXTE BOUCHON / A MODIFIER] Si vous êtes producteur et vous souhaitez vous inscrire pour être référencé dans l'annuaire : <a href="/src/app/controller/cet.qstprod.controller.login.form.php">cliquez ici</a> [TEXTE BOUCHON / A MODIFIER]
      </p>
      <p>
        [TEXTE BOUCHON / A MODIFIER] Afin de pouvoir modifier ou créer du nouveau contenu dans l'annuaire, il faut être inscrit. Si déjà inscrit, connectez-vous. [TEXTE BOUCHON / A MODIFIER]
      </p>
      <a class="btn btn-success btn-block" href="/src/app/controller/cet.qstprod.controller.login.form.php" style="margin-top: 8px;">S'inscrire sur l'annuaire cetcal !</a>
    </div>
  </div>
</div>
<div class="row justify-content-lg-center">
  <div class="col-lg-6"> 
    <form class="form" action="/src/app/controller/cet.qstprod.controller.login.form.php" method="post">
      <label for="qstprod-email"> - Veuillez renseigner votre identifiant et mot de passe :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>
      <div class="cet-formgroup-container">
        <div class="input-group mb-3">
          <input class="form-control" name="qstprod-email" id="qstprod-email" type="text" placeholder="Email, n°de téléphone ou identifiant" aria-label="email ou identifiant">
        </div>
        <div class="input-group mb-3">
          <input class="form-control" name="qstprod-motdepasse" id="qstprod-motdepasse" type="password" placeholder="Mot de passe" aria-label="Mot de passe">
        </div>
        <button class="btn btn-primary btn-block" type="submit" style="margin-top: 8px;">Se connecter</button>
      </div>
      <small class="form-text text-muted" style="margin-top: 12px;">
        <a href="#"> - J'ai oublié mon mot de passe.</a><br>
        <a href="#"> - J'ai perdu mon identifiant de connexion.</a><br>
        <a href="/src/app/controller/cet.qstprod.controller.login.form.php"> - Producteur, je souhaite m'inscrire et être référencé.</a></small>  
    </form>
  </div>
</div>