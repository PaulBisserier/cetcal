<?php 
// SESSION start for data storage.
session_start();
// Prepare navigation :
$nav = htmlspecialchars($_POST['qstprod-signupbesoins-nav']);
if ($nav != 'valider' && $nav != 'retour') { /*Error de navigation TODO.*/ $nav = 'retour'; }
$status = $nav == 'valider' ? 'signupprods.form' : 'signupgen.form';

// POST form logic :
/* *****************************************************************************/
/* HTTP POST : var setup : *****************************************************/
// POST form logic - dans l'ordre du formulaire HTML :
require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/utils/cet.qstprod.utils.httpdataprocessor.php');
$dataProcessor = new HTTPDataProcessor();
//$form_qstgen_lieuxdist = $_POST['qstprod-ldist-qstgen[]'];
$form_qstgen_libre = $dataProcessor->processHttpFormData($_POST['qstprod-qstbesoinlibre']);

require_once($_SERVER['DOCUMENT_ROOT'].'/src/app/model/dto/cet.qstprod.signupbesoins.dto.php');
$besoinsDto = "";
$_SESSION['signupbesoins.form'] = serialize($besoinsDto);
/* *****************************************************************************/

// Apply navigation :
header('Location: /?status='.$status);
exit();
?>