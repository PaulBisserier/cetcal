<?php 
/**
require_once('../model/cdc.sicdcgetuser.model.php');
$email = htmlspecialchars(isset($_POST['qstprod-email']) ? $_POST['qstprod-email'] : "");
$motdepasse = htmlspecialchars(isset($_POST['qstprod-motdepasse']) ? $_POST['qstprod-motdepasse'] : "");
$sicdcGetUser = new SiCdcGetUser();
$data = $sicdcGetUser->getUser($email, $motdepasse);
*/
$status = 'signupgen.form';
$whitelist = ['127.0.0.1', '::1', 'localhost'];
$localhost = in_array($_SERVER['REMOTE_ADDR'], $whitelist);
$localhost ? header('Location: /?status='.$status) : header('Location: /?status='.$status);
exit();
?>