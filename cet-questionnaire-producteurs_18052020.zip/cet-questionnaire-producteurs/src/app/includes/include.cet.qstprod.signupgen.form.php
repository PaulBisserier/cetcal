<div id="qstprod-signup-form-container">
  <div class="d-flex justify-content-center">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
      <p>Veuillez reseigner les informations demandées.</p>
    Toutes les informations saisies sur annuaire-bio.org vous appartiennent et à tous moment il vous sera possible de les supprimer pour une raison qui vous est pertinente.</p>
      <p></p>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>

  <div class="d-flex justify-content-center">
    <form class="form" action="/src/app/controller/cet.qstprod.controller.signupgen.form.php">
      <label for="cdc-signup-email"> - Veuillez renseigner les information demandées ci-dessous :
        <small class="form-text text-muted" style="margin-top: 2px;">Cet annuaire garantie la confidentialité de vos données numériques.<br>
          <a href="#">Prendre connaissance de notre politique relative aux données numériques.</a>
        </small>
      </label>

      <!-- ------------------------- -->
      <!-- INPUTS formulaire START : ---
      <input class="form-control" id="qstprod-" name="qstprod-" type="text" placeholder="" aria-label=".">
      ---- ------------------------- -->
      <input class="form-control" id="qstprod-nom" name="qstprod-nom" type="text" placeholder="Nom de famille" aria-label="Nom de famille.">
      <input class="form-control" id="qstprod-prenom" name="qstprod-prenom" type="text" placeholder="Prénom" aria-label="Prénom.">
      <input class="form-control" id="qstprod-email" name="qstprod-email" type="text" placeholder="Adresse email" aria-label="Adresse email d'inscription.">
      <input class="form-control" id="qstprod-email-conf" name="qstprod-email-conf" type="text" placeholder="Confirmation adresse email" aria-label="Confirmer votre adresse email d'inscription.">
      <input class="form-control" id="qstprod-mdp" name="qstprod-mdp" type="password" placeholder="Mot de passe" aria-label="Mot de passe">
      <input class="form-control" id="qstprod-mdpconf" name="qstprod-mdpconf" type="password" placeholder="Confirmer le mot de passe" aria-label="Confirmer le mot de passe d'insciption">
      <input class="form-control" id="qstprod-numbtel-fix" name="qstprod-numbtel-fix" type="text" maxlength="10" placeholder="N° de téléphone fix." aria-label="Entrez votre numéro de téléphone. Un numéro valide est recommandé en cas de perte d'identifiants.">
      <input class="form-control" id="qstprod-numbtel-port" name="qstprod-numbtel-port" type="text" maxlength="10" placeholder="N° de téléphone mobile." aria-label="Entrez votre numéro de téléphone. Un numéro valide est recommandé en cas de perte d'identifiants.">
      
      <br>
      <label for="qstprod-nomferme"><small class="form-text text-muted">Renseignez vos informations d'adresse d'exploitation :</small></label>
      <input class="form-control" id="qstprod-nomferme" name="qstprod-nomferme" type="text" placeholder="Nom commercial de la ferme" aria-label="Nom commercial de la ferme.">
      <input class="form-control" id="qstprod-numvoie" name="qstprod-numvoie" type="text" placeholder="Numéro sur voirie" aria-label="Numéro sur voirie.">
      <input class="form-control" id="qstprod-rue" name="qstprod-rue" type="text" placeholder="Nom de rue, chemin, avenue, lieux dit ect" aria-label="Nom de rue, chemin, avenue, lieux dit ect.">
      <input class="form-control" id="qstprod-commune" name="qstprod-commune" type="text" placeholder="Commune" aria-label="Saissez votre commune.">
      <input class="form-control" id="qstprod-cp" name="qstprod-cp" type="text" maxlength="5" placeholder="Code postal" aria-label="Saissez votre code postal.">
      <input class="form-control" id="qstprod-cmpladrs" name="qstprod-cmpladrs" type="text" placeholder="Complément d'adresse" aria-label="Complément d'adresse.">
      
      <br>
      <label for="qstprod-www"><small class="form-text text-muted">Informations web et réseaux sociaux :</small></label>
      <input class="form-control" id="qstprod-www" name="qstprod-www" type="text" placeholder="Site internet si existant" aria-label="Adresse web de votre site internet.">
      <input class="form-control" id="qstprod-fb" name="qstprod-fb" type="text" placeholder="Page Facebook de la ferme si existant" aria-label="Adresse de votre page Facebook si existant.">
      <input class="form-control" id="qstprod-ig" name="qstprod-ig" type="text" placeholder="Page Instagram si existant" aria-label="Page Instagram siexistant.">
      <input class="form-control" id="qstprod-autrewww" name="qstprod-autrewww" type="text" placeholder="Adresse web autre." aria-label="Adresse web autre.">
      
      <br>
      <label for="qstprod-anneeinstall"><small class="form-text text-muted">Informations relatives à l'exploitation :</small></label>
      <input class="form-control" id="qstprod-anneeinstall" name="qstprod-anneeinstall" type="text" placeholder="Annee d'installation de l'exploitation" aria-label="Annee d'installation de l'exploitation.">
      <input class="form-control" id="qstprod-syndc" name="qstprod-syndc" type="text" placeholder="Associations professionnelles et/ou syndicales dont vous êtes adhérent" aria-label="Associations professionnelles et/ou syndicales dont vous êtes adhérent.">
      <input class="form-control" id="qstprod-orgcertifbio" name="qstprod-orgcertifbio" type="text" placeholder="Organisme certificateur BIO" aria-label="Organisme certificateur BIO.">
      <input class="form-control" id="qstprod-typeprod" name="qstprod-typeprod" type="text" placeholder="Type de production" aria-label="Type de production.">
      <input class="form-control" id="qstprod-surfacepc" name="qstprod-surfacepc" type="text" placeholder="Superficie cultivée en plein champ" aria-label="Superficie cultivée en plein champ.">
      <input class="form-control" id="qstprod-supserre" name="qstprod-supserre" type="text" placeholder="Superficie de culture serre" aria-label="Superficie de culture serre.">

      <br>
      <label><small class="form-text text-muted">De manière générale, quels sont vos lieux/organismes de distribution ?</small></label>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-ferme" name="qstprod-ldist-ferme">
        <label class="form-check-label text-muted" for="qstprod-ldist-ferme">Directement à la ferme.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-marches" name="qstprod-ldist-marches">
        <label class="form-check-label text-muted" for="qstprod-ldist-marches">Marché(s) locaux.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-magasins" name="qstprod-ldist-magasins">
        <label class="form-check-label text-muted" for="qstprod-ldist-magasins">Magasins, boutiques.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-ldist-assos" name="qstprod-ldist-assos">
        <label class="form-check-label text-muted" for="qstprod-ldist-assos">Associations et/ou groupements.</label>
      </div>

      <br>
      <label><small class="form-text text-muted">Quelles seraient vos besoins par rapport à un annuaire hébergé par une plateforme informatique ?</small></label>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-1" name="qstprod-besoins-1">
        <label class="form-check-label text-muted" for="qstprod-besoins-1">Une page de présentation faisant office de site Internet pour votre ferme.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-2" name="qstprod-besoins-2">
        <label class="form-check-label text-muted" for="qstprod-besoins-2">Un moyen de se faire connaître.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-3" name="qstprod-besoins-3">
        <label class="form-check-label text-muted" for="qstprod-besoins-3">La possibilité d'y commercialiser directement mes produits.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-4" name="qstprod-besoins-4">
        <label class="form-check-label text-muted" for="qstprod-besoins-4">Un outil qui facilite les relations producteurs/consommateurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-5" name="qstprod-besoins-5">
        <label class="form-check-label text-muted" for="qstprod-besoins-5">Un outil qui facilite la mise en réseau entre producteurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-6" name="qstprod-besoins-6">
        <label class="form-check-label text-muted" for="qstprod-besoins-6">Un outil pour donner de l'information sur la bio aux consommateurs.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-7" name="qstprod-besoins-7">
        <label class="form-check-label text-muted" for="qstprod-besoins-7">Un outil qui aide à l'installation de nouveaux producteurs bio.</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-8" name="qstprod-besoins-8">
        <label class="form-check-label text-muted" for="qstprod-besoins-8">Un outil pour organiser un « lobby bio » entre producteurs, consommateurs, élus engagés, associations...</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="qstprod-besoins-9" name="qstprod-besoins-9">
        <label class="form-check-label text-muted" for="qstprod-besoins-9">Un outil interactif qui fait circuler de l'information entre les consommateurs et les différents acteurs du bio.</label>
      </div>

      <br>
      <label for="qstprod-qstbesoinlibre"><small class="form-text text-muted">Un besoin n'est pas présent dans la liste ci-dessus, exprimez vous :</small></label>
      <input class="form-control" id="qstprod-qstbesoinlibre" name="qstprod-qstbesoinlibre" type="text" placeholder="Exprimez-vous sur vos attentes !" aria-label="Exprimez-vous sur vos attentes.">
      <!-- ------------------------ -->
      <!-- INPUTS formulaire STOP : -->      
      <!-- ------------------------ -->
      <button class="btn btn-lg btn-primary btn-block" type="submit" style="margin-top: 8px;">
        Valider ces informations.
      </button>
    </form>
  </div>
</div>