<?php
header('Location: /?');
exit();
?>