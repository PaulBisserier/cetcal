/**
 * Prevent form submit if any necessary fields are unset.
 */
 $(document).on("submit", "form", function(e) {
  if ($('#qstprod-signupprods-nav').val() == 'ajouter' && !$("input.is-invalid").length <= 0) {

    e.preventDefault(e);
    $('#modal-questionaire-titre').text("La fiche produit n'est pas complète");
    $('#modal-questionaire-paragraphe').text("Pour compléter une fiche produit il faut renseigner les champs obligatoires.");
    $('#modal-questionaire-btn-primary').text("J'ai compris");
    $('#modal-questionaire-btn').click(); 
    return false;
  }
});

/**
 * Specific to removal navigation.
 * Prepare form for submit in a delete array entry context.
 */
 function removeProductFromTable(pIndex) {
  $('#qstprod-signupprods-nav').val('supprimer');
  $('#qstprod-signupprods-nav-pindex').val(pIndex);
}

function displayFicheProduit() {
  $('#cet-fiche-produit').toggle(400, 
    function() { 
      $('#cet-types-produits').toggle(400); 
    }
    );
}

/*
$(function() {
  $('#qstprod-produits-recherche').on('change', function() {
    var data = $('#qstprod-produits-recherche').val().split(' : ');  
    var pclass = data[0];
    var product = data[1];
    $('#qstprod-produits-recherche').val(product);
    $('#qstprod-produits-recherche-selected').val(data[0] + data[1]);
  });
});
*/

$(function() {
  $('#qstprod-produits-recherche').on('blur', function() {
    if ($('#qstprod-produits-recherche').val().indexOf(' : ') <= -1) {
      $('#qstprod-produits-recherche').val('');
    }
  });
});

function ajouterProduitListing() {
  var data = $('#qstprod-produits-recherche').val().split(' : ');
  var type = "";

  if (data === 'undefined' || data.length < 2) return;
  if ($('#qstprod-produits-recherche').val().indexOf(' : ') <= -1) {
      $('#qstprod-produits-recherche').val('');
      return;
  }

  if (data[0] === 'fruit') type = 'info';
  else if (data[0] === 'legume') type = 'success';
  else if (data[0] === 'fromage') type = 'danger';
  else if (data[0] === 'fleur') type = 'warning';
  else return;

  $('#cet-produits-zone-recap').fadeIn();
  $('#qstprod-produits-recherche-recap').append('<button type="button" ' + 
    'class="cet-recherche-produit-element-btn btn btn-sm btn-outline-' + type + 
    '">' + data[1] + ' <span aria-hidden="true">&times;</span></button>');
  $('#label-resultats-recherche-produits').hide();
  $('#qstprod-produits-recherche').val('');
}