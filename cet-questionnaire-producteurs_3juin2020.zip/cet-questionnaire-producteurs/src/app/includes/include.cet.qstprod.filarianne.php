<!-- Fil d'Arianne -->
<div class="row justify-content-lg-center" style="margin-bottom: 8px;">
  <div class="col-lg-6 align-middle">
    <label class="align-middle">
      <small class="form-text text-muted">
        <?= CetQstProdFilArianneHelper::$prefix_fa ?>
      </small>
    </label>
    <label class="align-middle"><?= CetQstProdFilArianneHelper::update($statut); ?></label>
  </div>
</div>