 <?php
Class FileReaderUtils
{
  private $PHP_FILES_PATH = "/res/data/";
  private $doc_root = "";
  public $temp = NULL;

  function __construct($DOC_ROOT) 
  {
    $this->doc_root = $DOC_ROOT;
  }

  public function read($fileName)
  {
    if (file_exists($this->doc_root.$this->PHP_FILES_PATH.$fileName))
    {
      $this->temp = array();
      $file = fopen($this->doc_root.$this->PHP_FILES_PATH.$fileName, "r");
      while(!feof($file)) array_push($this->temp, fgets($file));
      fclose($file);
      return $this->temp;
    }
  }
}
?> 